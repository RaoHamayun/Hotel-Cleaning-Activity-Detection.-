# My First Project > 2025-08-05 3:27pm
https://universe.roboflow.com/asdfas-qnsdt/my-first-project-pupkn-ej3rh

Provided by a Roboflow user
License: CC BY 4.0

